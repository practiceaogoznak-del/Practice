import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.application.*
import io.ktor.server.response.*
import io.ktor.server.request.*
import io.ktor.server.routing.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.plugins.contentnegotiation.*
import kotlinx.serialization.Serializable
import java.sql.Connection
import java.sql.DriverManager
import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.*

fun main() {
    embeddedServer(Netty, port = 8080, host = "0.0.0.0") {
        install(ContentNegotiation) {
            json()
        }

        routing {
            get("/") {
                call.respondText("Server is running ✅")
            }

            get("/check/{number}") {
                val number = call.parameters["number"] ?: ""
                val result = checkNumberStatus(number)
                call.respond(result)
            }

            post("/update") {
                val req = call.receive<UpdateRequest>()
                val success = updateNumberStatus(req.number, req.workerId)
                call.respond(mapOf("success" to success))
            }
        }
    }.start(wait = true)
}

// --- PostgreSQL ---
val dbUrl = "jdbc:postgresql://10.6.50.167:5433/postgres"
val dbUser = "postgres"
val dbPass = "1234"

fun getConnection(): Connection = DriverManager.getConnection(dbUrl, dbUser, dbPass)

// --- Data classes ---
@Serializable
data class CheckResponse(val message: String, val canProcess: Boolean, val color: String)

@Serializable
data class UpdateRequest(val number: String, val workerId: String)

// --- Functions ---
fun checkNumberStatus(number: String): CheckResponse {
    if (number.length != 10) return CheckResponse("Неверный формат номера", false, "dim_red")

    val series1 = number.substring(0, 2)
    val series2 = number.substring(2, 4)
    val numberPart = number.substring(4, 10)

    getConnection().use { conn ->
        val stmt = conn.prepareStatement(
            "SELECT checked_datetime, checked_tabnom FROM zadelka WHERE series1 = ? AND series2 = ? AND number = ?"
        )
        stmt.setString(1, series1)
        stmt.setString(2, series2)
        stmt.setString(3, numberPart)
        val rs = stmt.executeQuery()
        return if (rs.next()) {
            val checkedDate = rs.getTimestamp("checked_datetime")
            val checkedTabnom = rs.getString("checked_tabnom")
            if (checkedDate != null && checkedTabnom != null) {
                val dateStr = SimpleDateFormat("dd.MM.yyyy").format(checkedDate)
                CheckResponse("Заделан. Проверен ($dateStr)", false, "dim_yellow")
            } else {
                CheckResponse("Направлен на заделку", true, "dim_green")
            }
        } else {
            CheckResponse("На заделку не отправлялся", false, "dim_red")
        }
    }
}

fun updateNumberStatus(number: String, workerId: String): Boolean {
    if (number.length != 10) return false

    val series1 = number.substring(0, 2)
    val series2 = number.substring(2, 4)
    val numberPart = number.substring(4, 10)

    getConnection().use { conn ->
        val dateStr = SimpleDateFormat("yyyy-MM-dd").format(Date())
        val stmt = conn.prepareStatement(
            """
            INSERT INTO zadelka (series1, series2, number, input_tabnom, input_datetime, checked_tabnom, checked_datetime)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (series1, series2, number)
            DO UPDATE SET checked_tabnom = ?, checked_datetime = ?
            """
        )
        stmt.setString(1, series1)
        stmt.setString(2, series2)
        stmt.setString(3, numberPart)
        stmt.setString(4, workerId)
        stmt.setTimestamp(5, Timestamp(System.currentTimeMillis()))
        stmt.setString(6, workerId)
        stmt.setTimestamp(7, Timestamp.valueOf("$dateStr 00:00:00"))
        stmt.setString(8, workerId)
        stmt.setTimestamp(9, Timestamp.valueOf("$dateStr 00:00:00"))

        val rowsAffected = stmt.executeUpdate()
        return rowsAffected > 0
    }
}
